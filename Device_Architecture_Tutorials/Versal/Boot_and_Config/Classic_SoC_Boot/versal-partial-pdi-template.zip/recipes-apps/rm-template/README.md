# Template for application recipe to add the partial/rm design

How to add new recipe named rm-module-test
--------

1. Create a recipe directory and files directory under it
```
mkdir -p $(PLNX_ROOT)/project-spec/meta-dfx-common/recipe-apps/rm-module-test/files
```
2. Copy the bitbake file for the new copy from template and create required files for recipe
```
cp $(PLNX_ROOT)/project-spec/meta-dfx-common/recipe-apps/rm-template/rm-template.bb $(PLNX_ROOT)/project-spec/meta-dfx-common/recipe-apps/rm-module-test/rm-module-test.bb
touch $(PLNX_ROOT)/project-spec/meta-dfx-common/recipe-apps/rm-module-test/files/shell.json
```
3. Add the xsa file (It must have \*partial.pdi as one of the file) and name it as partial.xsa
```
cp /path/to/xsa/file/for/this/rm/design/*.xsa $(PLNX_ROOT)/project-spec/meta-dfx-common/recipe-apps/rm-module-test/files/partial.xsa
```
4. Add recipe to the package group ($(PLNX_ROOT)/project-spec/meta-dfx-common/recipes-core/packagegroups/packagegroup-dfx.bb)
```
	USR_APPS = " \
		rm-module-test \
        "

```

